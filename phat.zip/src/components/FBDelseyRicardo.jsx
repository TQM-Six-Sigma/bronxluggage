const FBDelseyRicardo = () => {
    return ( <><div>DelseyRicardo</div></> );
}
 
export default FBDelseyRicardo;