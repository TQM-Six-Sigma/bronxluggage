const FBBrics = () => {
    return ( <>
    <div>Brics</div>
    </> );
}
 
export default FBBrics;