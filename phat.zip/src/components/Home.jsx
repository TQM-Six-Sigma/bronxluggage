import React from 'react';
/* import ReactDOM from 'react-dom'
import AboutUs from './AboutUs';
import Gallery from './Gallery';
import Blog from './Blog';
import FeatureBrand from './FeatureBrand' */
import Navbar from './Navbar';
import Footer from './Footer';
import Content from './Content';
const Home = () => {
    return ( <>
    <div className="row">
       <div><Navbar/></div>
       <div>
        <Content/>
       </div>
        
    </div>
    <div>
        <Footer/>
    </div>
    
    </> );
}
 
export default Home;