const FBSamsonite = () => {
    return ( <><div>Samsonite</div></> );
}
 
export default FBSamsonite;