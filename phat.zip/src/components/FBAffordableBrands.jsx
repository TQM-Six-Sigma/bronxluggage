const FBAffordableBrands = () => {
    return ( <><div>AffordableBrands</div></> );
}
 
export default FBAffordableBrands;