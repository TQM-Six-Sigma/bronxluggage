const Footer = () => {
    return ( <>
    <div class="row container-fluid bg-primary fixed-bottom">
        <div class="col-12 text-center text-white">
            <div class="row"> 
                <div class="col-md-4 col-sm-12">
                    <p>Copyright © 2024. All Rights Reserved.</p>
                </div>
                <div class="col-md-4 col-sm-12">
                    <p>Designed by:</p>
                </div>
                <div class="col-md-4 col-sm-12">
                    <p>Contact: </p>
                </div>
            </div>
        </div>

    </div>
    
    </> );
}
 
export default Footer;