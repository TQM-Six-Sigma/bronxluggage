const FBTravelPro = () => {
    return ( <><div>TravelPro</div></> );
}
 
export default FBTravelPro;