const Gallery = () => {
    return ( <>
    </> );
}
 
export default Gallery;